import { useState, useEffect } from 'react'
import Head from 'next/head'

export default function Admin() {
  const [urls, setUrls] = useState([])
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [stats, setStats] = useState({ totalUrls: 0, totalClicks: 0 })

  // Admin credentials - Inko Vercel mein environment variables mein set karein
  const ADMIN_EMAIL = 'admin@umairattaa.com'
  const ADMIN_PASSWORD = 'UmairAdmin123!'

  useEffect(() => {
    const auth = localStorage.getItem('umair_admin_auth')
    if (auth) {
      setIsAuthenticated(true)
      fetchUrls()
    }
  }, [])

  const fetchUrls = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/urls')
      const data = await response.json()
      if (data.success) {
        setUrls(data.urls)
        
        const totalClicks = data.urls.reduce((sum, url) => sum + url.clicks, 0)
        setStats({
          totalUrls: data.urls.length,
          totalClicks: totalClicks
        })
      }
    } catch (error) {
      console.error('Error fetching URLs:', error)
      alert('Error loading URLs')
    } finally {
      setLoading(false)
    }
  }

  const handleLogin = (e) => {
    e.preventDefault()
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      localStorage.setItem('umair_admin_auth', 'true')
      fetchUrls()
    } else {
      alert('❌ Invalid admin credentials')
    }
  }

  const handleDelete = async (slug) => {
    if (confirm('Are you sure you want to delete this URL?')) {
      try {
        const response = await fetch('/api/urls', {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ slug }),
        })
        
        const data = await response.json()
        if (data.success) {
          setUrls(urls.filter(url => url.slug !== slug))
          alert('✅ URL deleted successfully')
          fetchUrls()
        }
      } catch (error) {
        alert('❌ Error deleting URL')
      }
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setEmail('')
    setPassword('')
    localStorage.removeItem('umair_admin_auth')
  }

  if (!isAuthenticated) {
    return (
      <div className="admin-login">
        <Head>
          <title>Admin Login - Umair URL Shortener</title>
        </Head>
        
        <div className="login-container">
          <form onSubmit={handleLogin} className="login-form">
            <div className="login-header">
              <h2>🔐 Admin Login</h2>
              <p>Umair URL Shortener Admin Panel</p>
            </div>
            
            <div className="input-group">
              <label>📧 Admin Email</label>
              <input
                type="email"
                placeholder="Enter admin email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div className="input-group">
              <label>🔑 Password</label>
              <input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            <button type="submit">🚀 Login</button>
          </form>
        </div>

        <style jsx>{`
          .admin-login {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem;
          }

          .login-container {
            width: 100%;
            max-width: 400px;
          }

          .login-form {
            background: white;
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
          }

          .login-header {
            text-align: center;
            margin-bottom: 2rem;
          }

          .login-header h2 {
            color: #333;
            margin-bottom: 0.5rem;
          }

          .login-header p {
            color: #666;
            font-size: 0.9rem;
          }

          .input-group {
            margin-bottom: 1.5rem;
          }

          label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
          }

          input {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            box-sizing: border-box;
          }

          input:focus {
            outline: none;
            border-color: #667eea;
          }

          button {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s ease;
          }

          button:hover {
            transform: translateY(-2px);
          }
        `}</style>
      </div>
    )
  }

  return (
    <div className="admin-container">
      <Head>
        <title>Admin Panel - Umair URL Shortener</title>
      </Head>

      <header>
        <div className="header-content">
          <h1>📊 Admin Panel</h1>
          <p>Umair URL Shortener Management</p>
        </div>
        <button onClick={handleLogout} className="logout-btn">🚪 Logout</button>
      </header>

      <div className="stats">
        <div className="stat-card">
          <h3>📈 Total URLs</h3>
          <p className="stat-number">{stats.totalUrls}</p>
        </div>
        <div className="stat-card">
          <h3>👆 Total Clicks</h3>
          <p className="stat-number">{stats.totalClicks}</p>
        </div>
      </div>

      <main>
        {loading ? (
          <div className="loading">⏳ Loading URLs...</div>
        ) : (
          <div className="urls-table-container">
            <h2>🔗 All Short URLs</h2>
            {urls.length === 0 ? (
              <div className="empty-state">
                <p>No URLs created yet</p>
                <a href="/" className="create-btn">Create First URL</a>
              </div>
            ) : (
              <div className="table-wrapper">
                <table className="urls-table">
                  <thead>
                    <tr>
                      <th>Short URL</th>
                      <th>Original URL</th>
                      <th>👆 Clicks</th>
                      <th>📅 Created</th>
                      <th>⚡ Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {urls.map((url) => (
                      <tr key={url._id}>
                        <td className="short-url">
                          <a 
                            href={`/${url.slug}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            {url.slug}
                          </a>
                        </td>
                        <td className="original-url" title={url.url}>
                          {url.url.length > 50 ? `${url.url.substring(0, 50)}...` : url.url}
                        </td>
                        <td className="clicks">{url.clicks}</td>
                        <td className="date">
                          {new Date(url.createdAt).toLocaleDateString()}
                        </td>
                        <td className="actions">
                          <button 
                            onClick={() => handleDelete(url.slug)}
                            className="delete-btn"
                            title="Delete URL"
                          >
                            🗑️ Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </main>

      <style jsx>{`
        .admin-container {
          min-height: 100vh;
          background: #f8f9fa;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        header {
          background: white;
          padding: 1.5rem 2rem;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .header-content h1 {
          color: #333;
          margin: 0 0 0.25rem 0;
        }

        .header-content p {
          color: #666;
          margin: 0;
          font-size: 0.9rem;
        }

        .logout-btn {
          background: #dc3545;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 8px;
          cursor: pointer;
          font-weight: 600;
        }

        .stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1.5rem;
          padding: 2rem;
          max-width: 1200px;
          margin: 0 auto;
        }

        .stat-card {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          box-shadow: 0 4px 15px rgba(0,0,0,0.1);
          text-align: center;
        }

        .stat-card h3 {
          margin: 0 0 1rem 0;
          color: #666;
          font-size: 1rem;
        }

        .stat-number {
          font-size: 2.5rem;
          font-weight: bold;
          color: #667eea;
          margin: 0;
        }

        main {
          padding: 0 2rem 2rem;
          max-width: 1200px;
          margin: 0 auto;
        }

        .loading {
          text-align: center;
          padding: 3rem;
          font-size: 1.2rem;
          color: #666;
        }

        .urls-table-container {
          background: white;
          border-radius: 12px;
          box-shadow: 0 4px 15px rgba(0,0,0,0.1);
          overflow: hidden;
        }

        .urls-table-container h2 {
          padding: 1.5rem 2rem;
          margin: 0;
          background: #f8f9fa;
          border-bottom: 1px solid #e1e5e9;
          color: #333;
        }

        .empty-state {
          padding: 3rem;
          text-align: center;
          color: #666;
        }

        .create-btn {
          display: inline-block;
          margin-top: 1rem;
          padding: 0.75rem 1.5rem;
          background: #667eea;
          color: white;
          text-decoration: none;
          border-radius: 8px;
          font-weight: 600;
        }

        .table-wrapper {
          overflow-x: auto;
        }

        .urls-table {
          width: 100%;
          border-collapse: collapse;
        }

        .urls-table th {
          background: #f8f9fa;
          padding: 1rem;
          text-align: left;
          font-weight: 600;
          color: #333;
          border-bottom: 1px solid #e1e5e9;
        }

        .urls-table td {
          padding: 1rem;
          border-bottom: 1px solid #e1e5e9;
        }

        .short-url a {
          color: #667eea;
          text-decoration: none;
          font-weight: 600;
        }

        .short-url a:hover {
          text-decoration: underline;
        }

        .original-url {
          max-width: 300px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .clicks {
          text-align: center;
          font-weight: 600;
          color: #28a745;
        }

        .date {
          color: #666;
          white-space: nowrap;
        }

        .actions {
          text-align: center;
        }

        .delete-btn {
          background: #dc3545;
          color: white;
          border: none;
          padding: 0.5rem 1rem;
          border-radius: 6px;
          cursor: pointer;
          font-size: 0.9rem;
        }

        @media (max-width: 768px) {
          header {
            flex-direction: column;
            gap: 1rem;
            text-align: center;
          }

          .stats {
            grid-template-columns: 1fr;
            padding: 1rem;
          }

          main {
            padding: 0 1rem 1rem;
          }

          .urls-table {
            font-size: 0.9rem;
          }

          .urls-table th,
          .urls-table td {
            padding: 0.5rem;
          }
        }
      `}</style>
    </div>
  )
}