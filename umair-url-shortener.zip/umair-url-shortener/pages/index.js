import { useState } from 'react'
import Head from 'next/head'

export default function Home() {
  const [url, setUrl] = useState('')
  const [slug, setSlug] = useState('')
  const [shortUrl, setShortUrl] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    
    try {
      const response = await fetch('/api/shorten', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url, slug }),
      })
      
      const data = await response.json()
      if (data.success) {
        setShortUrl(`${window.location.origin}/${data.slug}`)
        setUrl('')
        setSlug('')
      } else {
        alert(data.message || 'Error creating short URL')
      }
    } catch (error) {
      alert('Error creating short URL')
    }
    
    setLoading(false)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shortUrl)
    alert('Copied to clipboard!')
  }

  return (
    <div className="container">
      <Head>
        <title>Umair URL Shortener</title>
        <meta name="description" content="Free URL shortener service by Umair" />
      </Head>

      <main>
        <div className="header">
          <h1>🔗 Umair URL Shortener</h1>
          <p>Shorten your long URLs instantly</p>
        </div>
        
        <form onSubmit={handleSubmit} className="url-form">
          <div className="input-group">
            <label htmlFor="url">🌐 Long URL</label>
            <input
              type="url"
              id="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/very-long-url-path"
              required
            />
          </div>
          
          <div className="input-group">
            <label htmlFor="slug">✨ Custom Slug (optional)</label>
            <input
              type="text"
              id="slug"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              placeholder="my-custom-link"
            />
            <small>Leave empty for auto-generated slug</small>
          </div>
          
          <button type="submit" disabled={loading || !url}>
            {loading ? '⏳ Shortening...' : '🚀 Shorten URL'}
          </button>
        </form>

        {shortUrl && (
          <div className="result">
            <p>✅ Your short URL is ready:</p>
            <div className="url-display">
              <a href={shortUrl} target="_blank" rel="noopener noreferrer">
                {shortUrl}
              </a>
              <button onClick={copyToClipboard} className="copy-btn">
                📋 Copy
              </button>
            </div>
          </div>
        )}

        <div className="features">
          <h3>🌟 Features</h3>
          <ul>
            <li>✅ Free forever</li>
            <li>✅ Custom slugs</li>
            <li>✅ Click tracking</li>
            <li>✅ Fast redirects</li>
            <li>✅ Mobile friendly</li>
          </ul>
        </div>
      </main>

      <footer>
        <p>
          <a href="/admin">Admin Panel</a> | 
          Created by Umair
        </p>
      </footer>

      <style jsx>{`
        .container {
          min-height: 100vh;
          padding: 0 1rem;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        main {
          padding: 4rem 0;
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          width: 100%;
          max-width: 500px;
          margin: 0 auto;
        }

        .header {
          text-align: center;
          margin-bottom: 3rem;
        }

        h1 {
          color: white;
          margin-bottom: 0.5rem;
          font-size: 2.5rem;
        }

        .header p {
          color: rgba(255,255,255,0.8);
          font-size: 1.1rem;
        }

        .url-form {
          background: white;
          padding: 2.5rem;
          border-radius: 15px;
          box-shadow: 0 20px 40px rgba(0,0,0,0.1);
          width: 100%;
          margin-bottom: 2rem;
        }

        .input-group {
          margin-bottom: 1.5rem;
        }

        label {
          display: block;
          margin-bottom: 0.5rem;
          font-weight: 600;
          color: #333;
          font-size: 0.95rem;
        }

        input {
          width: 100%;
          padding: 1rem;
          border: 2px solid #e1e5e9;
          border-radius: 8px;
          font-size: 1rem;
          transition: all 0.3s ease;
          box-sizing: border-box;
        }

        input:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        small {
          display: block;
          margin-top: 0.25rem;
          color: #666;
          font-size: 0.85rem;
        }

        button {
          width: 100%;
          padding: 1rem;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 1.1rem;
          font-weight: 600;
          cursor: pointer;
          transition: transform 0.2s ease;
        }

        button:hover:not(:disabled) {
          transform: translateY(-2px);
        }

        button:disabled {
          opacity: 0.6;
          cursor: not-allowed;
          transform: none;
        }

        .result {
          background: white;
          padding: 2rem;
          border-radius: 15px;
          box-shadow: 0 20px 40px rgba(0,0,0,0.1);
          width: 100%;
          text-align: center;
          margin-bottom: 2rem;
        }

        .result p {
          margin-bottom: 1rem;
          font-weight: 600;
          color: #333;
        }

        .url-display {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        .url-display a {
          flex: 1;
          color: #667eea;
          text-decoration: none;
          font-weight: 600;
          word-break: break-all;
          padding: 0.75rem;
          background: #f8f9fa;
          border-radius: 8px;
          border: 1px solid #e1e5e9;
        }

        .copy-btn {
          width: auto;
          padding: 0.75rem 1.5rem;
          background: #28a745;
        }

        .features {
          background: white;
          padding: 2rem;
          border-radius: 15px;
          box-shadow: 0 20px 40px rgba(0,0,0,0.1);
          width: 100%;
        }

        .features h3 {
          text-align: center;
          margin-bottom: 1rem;
          color: #333;
        }

        .features ul {
          list-style: none;
          padding: 0;
        }

        .features li {
          padding: 0.5rem 0;
          color: #555;
        }

        footer {
          text-align: center;
          padding: 2rem 0;
          color: white;
        }

        footer a {
          color: white;
          text-decoration: none;
          margin: 0 0.5rem;
        }

        footer a:hover {
          text-decoration: underline;
        }

        @media (max-width: 600px) {
          .url-form, .result, .features {
            padding: 1.5rem;
          }
          
          h1 {
            font-size: 2rem;
          }
          
          .url-display {
            flex-direction: column;
          }
        }
      `}</style>
    </div>
  )
}