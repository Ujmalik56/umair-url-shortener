import clientPromise from '../../lib/mongodb'

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  try {
    const { slug } = req.query

    if (!slug) {
      return res.status(400).json({ message: 'Slug is required' })
    }

    const client = await clientPromise
    const db = client.db('urlshortener')
    const collection = db.collection('urls')

    const urlDoc = await collection.findOne({ slug })

    if (!urlDoc) {
      return res.status(404).json({ 
        message: 'Short URL not found' 
      })
    }

    await collection.updateOne(
      { slug },
      { 
        $inc: { clicks: 1 },
        $set: { lastAccessed: new Date() }
      }
    )

    res.redirect(302, urlDoc.url)

  } catch (error) {
    console.error('Error redirecting:', error)
    res.status(500).json({ message: 'Internal server error' })
  }
}