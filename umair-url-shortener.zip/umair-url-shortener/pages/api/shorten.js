import clientPromise from '../../lib/mongodb'
import { customAlphabet } from 'nanoid'

const alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
const nanoid = customAlphabet(alphabet, 6)

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  try {
    const { url, slug } = req.body
    
    if (!url) {
      return res.status(400).json({ message: 'URL is required' })
    }

    try {
      new URL(url)
    } catch (error) {
      return res.status(400).json({ message: 'Invalid URL format' })
    }

    const client = await clientPromise
    const db = client.db('urlshortener')
    const collection = db.collection('urls')

    let finalSlug = slug || nanoid()

    if (slug) {
      const existing = await collection.findOne({ slug: finalSlug })
      if (existing) {
        return res.status(400).json({ message: 'This custom slug is already taken' })
      }
    } else {
      let exists = true
      let attempts = 0
      while (exists && attempts < 5) {
        const existing = await collection.findOne({ slug: finalSlug })
        if (!existing) {
          exists = false
        } else {
          finalSlug = nanoid()
          attempts++
        }
      }
      
      if (exists) {
        return res.status(500).json({ message: 'Failed to generate unique slug' })
      }
    }

    await collection.insertOne({
      url: url,
      slug: finalSlug,
      clicks: 0,
      createdAt: new Date(),
      createdBy: 'user'
    })

    res.status(200).json({
      success: true,
      slug: finalSlug,
      shortUrl: `${process.env.NEXTAUTH_URL || 'https://xxxx1.vercel.app'}/${finalSlug}`
    })

  } catch (error) {
    console.error('Error creating short URL:', error)
    res.status(500).json({ message: 'Internal server error' })
  }
}